<?php
namespace App\Http\Controllers;

class CobaController extends Controller {
    public function index() {
        return view('home'); 
    }
    public function layanan() {
    $services = [
        [
            'id' => 'mesin',
            'judul' => 'Perbaikan Mesin', 
            'ket' => 'Melayani ganti oli, tune-up, pengecekan rem, diagnosa dengan scanner, serta spesialis perbaikan mesin, transmisi, dan kelistrikan.',
            'gambar' => ['mesin2.jpg', 'Mobil.jpg'] 
        ],
        [
            'id' => 'audio',
            'judul' => 'Setting Audio', 
            'ket' => 'Hadirkan kualitas suara premium di mobil Anda! Ditangani langsung oleh teknisi ahli menggunakan peralatan tuning terbaru untuk menghasilkan performa audio high-end yang sempurna.',
            'gambar' => ['Audio.jpg','FreqAudio.jpg']
        ],
        [
            'id' => 'modifikasi',
            'judul' => 'Modifikasi & Tuning', 
            'ket' => 'Peningkatan performa mobil untuk harian maupun balap (remap ECU, porting, dll).',
            'gambar' => ['Venturer.jpg', 'Hasil1.jpg', 'Hasil2.jpg']
        ]
    ];
    return view('services', compact('services')); 
}
    public function tentang() {
        $dataStatistik = [
            'labels' => ['Tune Up', 'Perbaikan Transmisi', 'Overhaul', 'Upgrade Mesin & Pengereman', 'Pasang Aksesoris & Audio'],
            'values' => [80, 60, 30, 70, 50]
        ];
        return view('about', compact('dataStatistik'));
    }
    public function kontak() {
        return view('contact'); 
    }
}