@extends('app')

@section('content')
<div class="video-bg-container">
    <video autoplay muted loop playsinline>
        <source src="{{ asset('VIDEO/General_Racing.mp4') }}" type="video/mp4">
    </video>
</div>
<div class="video-overlay"></div>

<div class="container video-page-content">
    <h1 class="text-center mb-5 display-5 fw-normal">ABOUT US</h1>

    <div class="row justify-content-center mb-5">
        <div class="col-md-9 text-center">
            <p class="fs-5 mb-4" style="line-height: 1.8;">
                Kami adalah bengkel spesialis yang berfokus pada kecepatan, kualitas, dan kepercayaan. 
                Melayani segala jenis perbaikan dan upgrade performa mobil Anda.
            </p>
            <p class="fs-5 opacity-75" style="line-height: 1.8;">
                Berdiri sejak tahun 1960, kami berkomitmen memberikan pelayanan prima dengan mekanik 
                yang tersertifikasi dan suku cadang yang terjamin keasliannya. 
                Mobil Anda di tangan yang tepat.
            </p>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card border-0 shadow-sm p-4">
                <h4 class="text-center fw-normal mb-4">STATISTIK LAYANAN PERBAIKAN PER BULAN</h4>
                
                <div id="qualityChart" style="width:100%; height:450px;"></div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Mengambil data dari variabel yang dikirim controller
        const labels = {!! json_encode($dataStatistik['labels']) !!};
        const values = {!! json_encode($dataStatistik['values']) !!};

        var data = [{
            x: labels,
            y: values,
            type: 'bar',
            marker: {
                color: [
                    'rgba(255, 255, 255, 0.9)', 
                    'rgba(255, 255, 255, 0.7)', 
                    'rgba(255, 255, 255, 0.5)',
                    'rgba(255, 255, 255, 0.3)', 
                    'rgba(255, 255, 255, 0.2)'  
                ]
            },
            text: values.map(v => v + '%'),
            textposition: 'auto',
            textfont: { color: '#000' } // Teks angka di dalam bar dibuat hitam agar terbaca
        }];

        var layout = {
            font: { 
                family: 'sans-serif', 
                size: 14,
                color: '#fff' // Warna teks luar (label) putih agar kontras dengan video
            },
            margin: { t: 20, b: 50, l: 60, r: 20 },
            paper_bgcolor: 'rgba(0,0,0,0)',
            plot_bgcolor: 'rgba(0,0,0,0)',
            yaxis: {
                title: 'Tingkat Kepuasan / Keberhasilan (%)',
                range: [0, 100],
                dtick: 20,       
                gridcolor: 'rgba(255,255,255,0.1)',
                color: '#fff'
            },
            xaxis: {
                gridcolor: 'rgba(0,0,0,0)',
                color: '#fff'
            }
        };

        var config = { 
            responsive: true,
            displayModeBar: false
        };

        Plotly.newPlot('qualityChart', data, layout, config);
    });
</script>
@endpush