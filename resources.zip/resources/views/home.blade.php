@extends('app')

@section('content')
<style>
    main.container { 
        max-width: 100% !important; 
        padding: 0 !important; 
        margin-top: 0 !important; 
        margin-bottom: 0 !important; 
    }
    .carousel-item img {
        height: 100vh;
        object-fit: cover; 
    }
</style>

<div id="heroCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="0" class="active"></button>
        <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="1"></button>
        <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="2"></button>
    </div>

    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="{{ asset('IMG/Servis.jpg') }}" class="d-block w-100" alt="Servis 1">
        </div>
        <div class="carousel-item">
            <img src="{{ asset('IMG/Part Rc.png') }}" class="d-block w-100" alt="Servis 2">
        </div>
        <div class="carousel-item">
            <img src="{{ asset('IMG/Mesin3.jpg') }}" class="d-block w-100" alt="Servis 3">
        </div>
    </div>
    
    <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
@endsection