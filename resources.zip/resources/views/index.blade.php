@extends('app')

@section('content')
    @include('home')
    @include('services')
    @include('about')
    @include('contact')
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var data = [{
            x: {!! json_encode($dataStatistik['labels']) !!},
            y: {!! json_encode($dataStatistik['values']) !!},
            type: 'bar',
            marker: { color: 'rgba(0,123,255,0.8)' }
        }];
        Plotly.newPlot('qualityChart', data, { responsive: true });
    });
</script>
@endpush