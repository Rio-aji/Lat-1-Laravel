@extends('app')

@section('content')
<div class="video-bg-container">
    <video autoplay muted loop playsinline><source src="{{ asset('VIDEO/General_Racing.mp4') }}" type="video/mp4"></video>
</div>
<div class="video-overlay"></div>
<div class="container video-page-content">
    <h1 class="text-center mb-5 display-5 fw-normal">LAYANAN KAMI</h1>
    <div class="row">
        @foreach ($services as $s)
        <div class="col-md-4 mb-4">
            <div class="card h-100 py-5 px-3 text-center" style="cursor: pointer;" data-bs-toggle="modal" data-bs-target="#modal-{{ $s['id'] }}">
                <div class="card-body">
                    <h3 class="fw-normal mb-3">{{ strtoupper($s['judul']) }}</h3>
                    <p class="fs-5">{{ $s['ket'] }}</p>
                </div>
            </div>
            <div class="modal fade" id="modal-{{ $s['id'] }}" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content text-dark">
                        <div class="modal-header">
                            <h5 class="modal-title">Dokumentasi: {{ $s['judul'] }}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row g-3">
                                @foreach ($s['gambar'] as $img)
                                <div class="col-6"><img src="{{ asset('IMG/' . $img) }}" class="img-fluid rounded"></div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection