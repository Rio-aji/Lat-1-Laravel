<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CobaController;

Route::get('/', [CobaController::class, 'index'])->name('home');
Route::get('/layanan', [CobaController::class, 'layanan'])->name('layanan');
Route::get('/tentang', [CobaController::class, 'tentang'])->name('tentang');
Route::get('/kontak', [CobaController::class, 'kontak'])->name('kontak');

Route::get('/todo', function () {
 return 'Halaman Todo App';
});

Route::get('/Hal1', function () {
    return view('welcome');
});

Route::get('/hal2', [CobaController::class, 'index']);