<h1>
    Selamat Datang
</h1>

<p>
    Nama : Rio Aji satria Prabowo
</p><?php /**PATH D:\Pemrograman Tk3\Laravel\todo-app\resources\views/Coba.blade.php ENDPATH**/ ?>