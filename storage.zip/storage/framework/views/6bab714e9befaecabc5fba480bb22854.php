

<?php $__env->startSection('content'); ?>
<div class="video-bg-container">
    <video autoplay muted loop playsinline><source src="<?php echo e(asset('VIDEO/General_Racing.mp4')); ?>" type="video/mp4"></video>
</div>
<div class="video-overlay"></div>
<div class="container video-page-content">
    <h1 class="text-center mb-5 display-5 fw-normal">LAYANAN KAMI</h1>
    <div class="row">
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card h-100 py-5 px-3 text-center" style="cursor: pointer;" data-bs-toggle="modal" data-bs-target="#modal-<?php echo e($s['id']); ?>">
                <div class="card-body">
                    <h3 class="fw-normal mb-3"><?php echo e(strtoupper($s['judul'])); ?></h3>
                    <p class="fs-5"><?php echo e($s['ket']); ?></p>
                </div>
            </div>
            <div class="modal fade" id="modal-<?php echo e($s['id']); ?>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content text-dark">
                        <div class="modal-header">
                            <h5 class="modal-title">Dokumentasi: <?php echo e($s['judul']); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row g-3">
                                <?php $__currentLoopData = $s['gambar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-6"><img src="<?php echo e(asset('IMG/' . $img)); ?>" class="img-fluid rounded"></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pemrograman Tk3\Laravel\todo-app\resources\views/services.blade.php ENDPATH**/ ?>