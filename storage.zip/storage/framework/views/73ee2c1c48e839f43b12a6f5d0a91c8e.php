

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('services', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('about', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('contact', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var data = [{
            x: <?php echo json_encode($dataStatistik['labels']); ?>,
            y: <?php echo json_encode($dataStatistik['values']); ?>,
            type: 'bar',
            marker: { color: 'rgba(0,123,255,0.8)' }
        }];
        Plotly.newPlot('qualityChart', data, { responsive: true });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pemrograman Tk3\Laravel\todo-app\resources\views/index.blade.php ENDPATH**/ ?>