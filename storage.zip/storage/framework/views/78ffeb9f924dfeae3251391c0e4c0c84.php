<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bengkel Tanjoeng Anoem Speed</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="<?php echo e(asset('mycustom.css')); ?>">

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm py-2">
        <div class="container-fluid px-5"> 
            <div class="full-spread">
                <a class="navbar-brand d-flex align-items-center fw-normal" href="<?php echo e(route('home')); ?>">
                    <img src="<?php echo e(asset('IMG/turbo.png')); ?>" alt="Logo" width="40" height="40" class="me-2">
                    <span>TANJOENG <span class="text-dark">ANOEM SPEED</span></span>
                </a>

                <div class="collapse navbar-collapse flex-grow-0" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('layanan') ? 'active' : ''); ?>" href="<?php echo e(route('layanan')); ?>">SERVICES</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('tentang') ? 'active' : ''); ?>" href="<?php echo e(route('tentang')); ?>">ABOUT</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('kontak') ? 'active' : ''); ?>" href="<?php echo e(route('kontak')); ?>">CONTACT</a>
                        </li>
                    </ul>
                </div>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
        </div>
    </nav>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="bg-white border-top mt-auto py-3">
        <div class="container-fluid px-5">
            <div class="d-flex justify-content-between align-items-center">
                
                <div class="d-flex align-items-center">
                    <img src="<?php echo e(asset('IMG/turbo.png')); ?>" alt="Logo Footer" class="me-2">
                    <div>
                        <h4 class="text-dark mb-0">TANJOENG ANOEM SPEED</h4>
                        <p class="text-muted mb-0">Bengkel Spesialis Performa Kendaraan.</p>
                    </div>
                </div>

                <div class="text-end text-muted">
                    <strong>Alamat:</strong> CR58+FMF, Tj. Ongih, Kwarasan, Grogol, Sukoharjo <br>
                    <strong>WhatsApp:</strong> +62 851-0302-1358
                </div>
            </div>

            <div class="text-center mt-2 pt-2 border-top text-muted footer-copyright">
                &copy; 2026 Tanjoeng Anoem Speed. All rights reserved.
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH D:\Pemrograman Tk3\Laravel\todo-app\resources\views/app.blade.php ENDPATH**/ ?>