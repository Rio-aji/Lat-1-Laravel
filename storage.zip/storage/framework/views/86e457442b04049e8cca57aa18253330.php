

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="text-center mb-5">
        <h1 class="fw-normal text-dark">CONTACT US</h1>
        <p class="text-muted">Hubungi kami melalui form di bawah ini atau kunjungi lokasi kami secara langsung.</p>
    </div>

    <div class="row g-5 mb-5">
        <div class="col-md-6">
            <div class="card border-0 shadow-sm p-4 h-100">
                <h5 class="fw-normal mb-4">Kirim Pesan</h5>
                <form id="contactForm">
                    <div class="mb-3">
                        <label class="form-label small text-muted">Nama Lengkap</label>
                        <input type="text" id="nama" class="form-control" placeholder="Masukkan nama Anda" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">No. WhatsApp</label>
                        <input type="text" id="no_hp" class="form-control" placeholder="Contoh: 08123456789" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Keluhan / Pesan</label>
                        <textarea id="keluhan" class="form-control" rows="4" placeholder="Jelaskan keluhan Anda" required></textarea>
                    </div>
                    <button type="button" onclick="showPopup()" class="btn btn-dark w-100 py-2">Kirim Pesan</button>
                </form>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card border-0 shadow-sm overflow-hidden mb-4" style="height: 350px;">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30568.251665103533!2d110.78780904277342!3d-7.58346411605963!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a160d003f2a41%3A0x75fb2b4247987a53!2sTanjoeng%20Anoem%20Speed!5e1!3m2!1sid!2sid!4v1772693243648!5m2!1sid!2sid" 
                    width="100%" 
                    height="100%" 
                    style="border:0;" 
                    allowfullscreen="" 
                    loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>

            <div class="p-2">
                <h6 class="fw-normal mb-2">Detail Kontak & Lokasi:</h6>
                <p class="text-muted small mb-3">
                    CR58+FMF, Tj. Ongih, Kwarasan, Kec. Grogol, Kabupaten Sukoharjo <br>
                    <strong>WhatsApp:</strong> +62 851-0302-1358
                </p>

                <h6 class="fw-normal mb-2">Social Media:</h6>
                <div class="d-flex gap-3">
                    <a href="https://www.instagram.com/ta_speed__?igsh=MTk3NGNnYTF4b2Q3MQ==" target="_blank" class="text-decoration-none d-flex align-items-center text-dark">
                        <img src="https://cdn-icons-png.flaticon.com/512/174/174855.png" width="20" height="20" class="me-2" alt="IG">
                        <span class="small">Instagram</span>
                    </a>
                    
                    <a href="https://www.tiktok.com/@tanjoenganoemspeed?_r=1&_t=ZS-94Qgvnf33A4" target="_blank" class="text-decoration-none d-flex align-items-center text-dark">
                        <img src="https://cdn-icons-png.flaticon.com/512/3046/3046121.png" width="20" height="20" class="me-2" alt="TikTok">
                        <span class="small">TikTok</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function showPopup() {
        const nama = document.getElementById('nama').value;
        const hp = document.getElementById('no_hp').value;
        const pesan = document.getElementById('keluhan').value;

        if (nama === "" || hp === "" || pesan === "") {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Harap isi semua kolom terlebih dahulu!',
                confirmButtonColor: '#000'
            });
            return;
        }

        Swal.fire({
            title: 'Berhasil!',
            text: 'Halo ' + nama + ', pesan Anda telah kami terima.',
            icon: 'success',
            confirmButtonText: 'Oke',
            confirmButtonColor: '#000'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('contactForm').reset();
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pemrograman Tk3\Laravel\todo-app\resources\views/contact.blade.php ENDPATH**/ ?>