<h1>
    Hello
</h1>

<p>
    NIM : 20236044
</p><?php /**PATH D:\Pemrograman Tk3\Laravel\todo-app\resources\views/Coba2.blade.php ENDPATH**/ ?>